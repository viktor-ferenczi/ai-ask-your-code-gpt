import psycopg2

Warning = psycopg2.Warning
Error = psycopg2.Error
InterfaceError = psycopg2.InterfaceError
DatabaseError = psycopg2.DatabaseError
DataError = psycopg2.DataError
OperationalError = psycopg2.OperationalError
IntegrityError = psycopg2.IntegrityError
InternalError = psycopg2.IntegrityError
ProgrammingError = psycopg2.ProgrammingError
NotSupportedError = psycopg2.NotSupportedError
