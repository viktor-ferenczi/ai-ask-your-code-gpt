""" Database backends

The base subpackage contains generic implementation can be reused by 
the SQL server specific backend implementations.

All the other subpackages contain SQL server specific implementations.

"""
