# noinspection PyUnresolvedReferences
from dblayer.backend.base.record import Record
