""" Unit test cases for the database package
"""
