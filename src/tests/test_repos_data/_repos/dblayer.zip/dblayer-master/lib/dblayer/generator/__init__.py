""" Database abstraction layer generator
"""
