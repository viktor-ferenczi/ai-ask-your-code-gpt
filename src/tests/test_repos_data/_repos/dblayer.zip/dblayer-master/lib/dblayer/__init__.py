""" DBLayer - Database Abstraction Layer Generator
"""

# FIXME: Require the first column to be the primary key one in all writable tables (not views).
