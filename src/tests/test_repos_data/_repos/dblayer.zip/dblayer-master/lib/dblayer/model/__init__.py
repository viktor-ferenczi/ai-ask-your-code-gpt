""" Classes to build database models
"""
